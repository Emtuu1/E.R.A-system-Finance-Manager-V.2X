from flask import Blueprint, render_template

finance_bp = Blueprint('finance', __name__)

@finance_bp.route('/finance')
def finance():
    return render_template('finance.html')
