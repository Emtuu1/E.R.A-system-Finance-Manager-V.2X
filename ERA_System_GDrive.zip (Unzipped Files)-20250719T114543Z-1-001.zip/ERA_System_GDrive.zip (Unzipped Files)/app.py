from flask import Flask
from auth import auth_bp
from vault import vault_bp
from finance import finance_bp

app = Flask(__name__)
app.secret_key = 'era-super-secret-key'

app.register_blueprint(auth_bp)
app.register_blueprint(vault_bp)
app.register_blueprint(finance_bp)

if __name__ == '__main__':
    app.run(debug=True)
